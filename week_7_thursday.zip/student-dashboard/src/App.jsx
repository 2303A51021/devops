import Header from "./components/Header";
import StudentProfile from "./components/StudentProfile";
import SubjectList from "./components/SubjectList";
import Attendance from "./components/Attendance";
import ExamDetails from "./components/ExamDetails";
import Footer from "./components/Footer";

import "./App.css";

function App() {
  const student = {
    name: "Ashwitha",
    rollNo: "23CSBTB01",
    branch: "Computer Science Engineering",
    year: "3rd Year"
  };

  const subjects = [
    "DevOps and Fullstack",
    "Data Structures",
    "Database Management Systems",
    "Operating Systems",
    "Computer Networks"
  ];

  return (
    <div>
      <Header />

      <main className="dashboard">

        <StudentProfile
          name={student.name}
          rollNo={student.rollNo}
          branch={student.branch}
          year={student.year}
        />

        <SubjectList subjects={subjects} />

        <Attendance percentage={85} />

        <ExamDetails />

      </main>

      <Footer />
    </div>
  );
}

export default App;