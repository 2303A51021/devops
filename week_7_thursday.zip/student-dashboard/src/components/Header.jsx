function Header() {
  return (
    <header>
      <h1>Student Management Dashboard</h1>
      <p>SR University</p>
    </header>
  );
}

export default Header;