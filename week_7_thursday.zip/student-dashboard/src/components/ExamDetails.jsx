function ExamDetails() {
  return (
    <div className="card">
      <h2>Examination Details</h2>

      <p><b>Exam:</b> Mid Term Examination</p>
      <p><b>Date:</b> 25 September 2026</p>
      <p><b>Semester:</b> Odd Semester</p>
    </div>
  );
}

export default ExamDetails;