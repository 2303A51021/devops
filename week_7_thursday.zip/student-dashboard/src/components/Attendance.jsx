function Attendance({ percentage }) {
  return (
    <div className="card">
      <h2>Attendance</h2>

      <p className="attendance">
        {percentage}%
      </p>

      <p>
        {percentage >= 75 ? "Eligible" : "Not Eligible"}
      </p>
    </div>
  );
}

export default Attendance;