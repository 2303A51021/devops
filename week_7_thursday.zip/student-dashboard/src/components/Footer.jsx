function Footer() {
  return (
    <footer>
      <p>© 2026 Student Management Dashboard</p>
    </footer>
  );
}

export default Footer;