function StudentProfile({ name, rollNo, branch, year }) {
  return (
    <div className="card">
      <h2>Student Profile</h2>

      <p><b>Name:</b> {name}</p>
      <p><b>Roll Number:</b> {rollNo}</p>
      <p><b>Branch:</b> {branch}</p>
      <p><b>Year:</b> {year}</p>
    </div>
  );
}

export default StudentProfile;