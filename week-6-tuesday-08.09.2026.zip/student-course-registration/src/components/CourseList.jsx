function CourseList({ courses, onRegister }) {
  return (
    <div>
      <h2>Available Courses</h2>

      {courses.map((course) => (
        <div key={course.id}>
          <p>
            {course.name} - {course.department} - {course.credits} Credits
          </p>

          <button onClick={() => onRegister(course)}>
            Register
          </button>
        </div>
      ))}
    </div>
  );
}

export default CourseList;