function StudentProfile() {
  return (
    <div>
      <h2>Student Profile</h2>
      <p>Name: Ashwitha</p>
      <p>Roll No: 23CSBTB01</p>
      <p>Department: CSE</p>
    </div>
  );
}

export default StudentProfile;