function Course() {
  return (
    <div>
      <h2>Course</h2>
      <p>Course details will be displayed here.</p>
    </div>
  );
}

export default Course;