function Registration({ courses, onRemove }) {
  return (
    <div>
      <h2>Registered Courses</h2>

      {courses.length === 0 ? (
        <p>No courses registered.</p>
      ) : (
        courses.map((course) => (
          <div key={course.id}>
            <p>{course.name} - {course.credits} Credits</p>
            <button onClick={() => onRemove(course.id)}>
              Remove
            </button>
          </div>
        ))
      )}
    </div>
  );
}

export default Registration;