function Footer() {
  return (
    <footer>
      <p>© 2026 Student Course Registration System</p>
    </footer>
  );
}

export default Footer;