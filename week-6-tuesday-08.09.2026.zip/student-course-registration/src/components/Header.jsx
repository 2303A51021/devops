function Header() {
  return (
    <header className="header">
      <h1>SR University</h1>

      <nav className="nav">
        <a href="#">Home</a>
        <a href="#courses">Courses</a>
        <a href="#registration">Registration</a>
      </nav>
    </header>
  );
}

export default Header;