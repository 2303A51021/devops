import "./App.css";
import { useState } from "react";
import Header from "./components/Header";
import StudentProfile from "./components/StudentProfile";
import CourseList from "./components/CourseList";
import Registration from "./components/Registration";
import Footer from "./components/Footer";

function App() {
  const courses = [
    { id: 1, name: "Web Development", department: "CSE", credits: 3 },
    { id: 2, name: "Database Management", department: "CSE", credits: 4 },
    { id: 3, name: "Data Structures", department: "CSE", credits: 3 },
    { id: 4, name: "Artificial Intelligence", department: "AI", credits: 4 }
  ];

  const [registeredCourses, setRegisteredCourses] = useState([]);

  const registerCourse = (course) => {
    if (!registeredCourses.some((item) => item.id === course.id)) {
      setRegisteredCourses([...registeredCourses, course]);
    }
  };

  const removeCourse = (id) => {
    setRegisteredCourses(
      registeredCourses.filter((course) => course.id !== id)
    );
  };

  return (
    <>
      <Header />

      <main>
        <StudentProfile />

        <CourseList
          courses={courses}
          onRegister={registerCourse}
        />

        <Registration
          courses={registeredCourses}
          onRemove={removeCourse}
        />
      </main>

      <Footer />
    </>
  );
}

export default App;